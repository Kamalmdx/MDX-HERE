const settings = {
  'packname': "𝙕𝙖𝙣𝙞𝙩𝙨𝙪 𝙗𝙤𝙩",
  'author': 'CHRIS GAAJU',
  'botName': "𝙕𝙖𝙣𝙞𝙩𝙨𝙪 𝙗𝙤𝙩",
  'botOwner': "CHRIS GAAJU",
  'ownerNumber': "2348069675806",
  'giphyApiKey': "qnl7ssQChTdPjsKta2LMaGXz303tq",
  'commandMode': 'public',
  'maxStoreMessages': 0x14,
  'storeWriteInterval': 0x2710,
  'description': "This is a bot for managing group commands and automating tasks.",
  'version': "1.0.0",
  'updateZipUrl': 'https://github.com/qwerghjkkl/Benzo-MD-bot/archive/refs/heads/main.zip'
};
module.exports = settings;
